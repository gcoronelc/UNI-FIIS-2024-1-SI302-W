/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proy1_bernal.prueba;

import com.mycompany.proy1_bernal.service.BookService;


public class Prueba06 {
    public static void main(String[] args) {
        try {
            //variables
            
            
            // Proceso
            BookService service = new BookService();
            service.RegistroVenta(cliente,fecha, id_emp, publi, cant,dscto );
            System.out.println("Proceso Ok.");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
